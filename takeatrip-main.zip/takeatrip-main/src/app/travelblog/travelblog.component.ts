import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-travelblog',
  templateUrl: './travelblog.component.html',
  styleUrls: ['./travelblog.component.css']
})
export class TravelblogComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
